
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ris";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

 if(isset($_POST['na_voljo'])){
	 $na_voljo=1;
 }else{
	 $na_voljo=0;
 }
$sql="INSERT INTO artikel (ime_artikla,namen_uporabe,kraj,datum_vrnitve,status)
VALUES
('$_POST[naziv_artikla]','$_POST[izbira]','$_POST[kraj]','$_POST[datum_vrnitve]','$na_voljo')";
 
if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>